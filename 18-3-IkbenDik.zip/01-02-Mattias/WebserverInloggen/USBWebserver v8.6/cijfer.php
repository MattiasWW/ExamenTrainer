<!Doctype html>
<head>Dikke truuk</head>

<body> 

<div>
<?php
if ($_SESSION['cijfer'] >= 5,5) {
 print "goed gedaan dikke trula je hebt een $_SESSION['cijfer']";
} else if ($_SESSION['cijfer'] < 5,5 AND $_SESSION['cijfer'] > 3,5) {
 print "jij moet mokertje veel oefenen pikketrekker je hebt een $_SESSION['cijfer']";
else {
 print "een twee honderd jij wordt van het vwo afgedonderd je hebt een $_SESSION['cijfer']. De slavenplantage heeft nog werk voor je";
}
?>
</div>

</body>
</html>