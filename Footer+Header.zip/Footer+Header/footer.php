<DOCTYPE html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="theme.css">
	<link rel="stylesheet" type="text/css" href="menu.css">
	
</head>

<body>	
	<div class="footer">
		<div class="instellingen">
			<a href="localhost:8080/instellingen.html">instellingen</a> 
				<br>
			<a href="localhost:8080/profiel.html">profiel</a>
				<br>
			<a href="localhost:8080/resultaten.html">resultaten</a>
		</div>
		<div class="talenkeuze">
			<a href="localhost:8080/duits.html">duits</a>
				<br>
			<a href="localhost:8080/engels.html">engels</a>
				<br>
			<a href="localhost:8080/frans.html">frans</a>
		</div>
		<div class="inloggen">
			<a href="localhost:8080/registreren.html">registreren</a>
				<br>
			<a href="localhost:8080/inloggen.html">inloggen</a>
				<br>
			<a href="localhost:8080/wachtwoordvergeten.html">wachtwoord vergeten</a>
		</div>
		<div class="copyright">
			<p>© 2019 ~ 2018 Passam ExamenTrainer ~ Greijdanus College 1959</p>
		</div>
	</div>
</body>
</html>