<DOCTYPE html>
<head>
	<link rel="stylesheet" type="text/css" href="theme.css">
	<link rel="stylesheet" type="text/css" href="menu.css">
	
</head>
<body>
	<div class="header">
		<a href="localhost:8080//Home.html" class="logo">
		<div>
			<img src="https://raw.githubusercontent.com/aidsfonds88/ExamenTrainer/master/passam.jpg" alt="Passam" class="passam">
		</div>
		</a>
		 <div class="headerright">
			 <button onclick="myFunction()" class="dropbtn"></button>
				<div id="myDropdown" class="dropdown-content">
					<a href="localhost:8080/Home.html">Home</a>
					<a href="localhost:8080/instellingen.html">Instellingen</a>
					<a href="localhost:8080/logout.html">Log Out</a>
				</div>
		 </div>
	</div>

	<script src="menu.js"></script>

</body>
</html>