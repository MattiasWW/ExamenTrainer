<!DOCTYPE html>
<html>
	<head>
		<title>Opdracht</title>
	</head>
<body>
<form action="VOLGENDE OPDRACHT A SABIIIIIIIII.php" method="post">
			<table> 
				<tr><td>A</td><td><input type="radio" name="Antwoord" value="A" checked="checked"></td></tr>
				<tr><td>B</td><td><input type="radio" name="Antwoord" value="B" ></td></tr>
				<tr><td>C</td><td><input type="radio" name="Antwoord" value="C" ></td></tr>
				<tr><td>D</td><td><input type="radio" name="Antwoord" value="D" ></td></tr>

				<tr><td></td><td><input type="submit" name="OK" value="OK"></td></tr>
			</table>
		</form>
		
		</body>
		</html>