<?php
session_start();
if (isset($_POST['OK'])) {
$Antwoord = $_POST['Antwoord'];
if ($selected_opleiding == 'A') {
	$A = 'checked';
	$B = 'unchecked';
	$C = 'unchecked';
	$D = 'unchecked';

} else if($selected_opleiding == 'B') {
	$A = 'unchecked';
	$B = 'checked';
	$C = 'unchecked';
	$D = 'unchecked';

}  else if($selected_opleiding == 'C') {
	$A = 'unchecked';
	$B = 'unchecked';
	$C = 'checked';
	$D = 'unchecked';

} else if($selected_opleiding == 'D') {
	$A = 'unchecked';
	$B = 'unchecked';
	$C = 'unchecked';
	$D = 'checked';

}
$doorgaan = false;
}

session_destroy();
?>